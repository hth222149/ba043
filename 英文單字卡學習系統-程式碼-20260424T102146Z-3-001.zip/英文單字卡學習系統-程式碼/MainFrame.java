package 作業2;

import javax.swing.*;

import java.awt.*;

import java.awt.event.*;

import java.util.HashMap;

import java.util.ArrayList;

import java.util.List;

 

public class MainFrame extends JFrame {

 

private CardLayout cardLayout;

private JPanel cardPanel;

private JTabbedPane tabbedPane;

private HashMap<String, JPanel> panelMap;

 

public static List<String[]> wrongWords = new ArrayList<>();

public static int totalAnswered = 0;

public static int totalCorrect = 0;

 

public MainFrame() {

setTitle("英文單字學習系統");

setDefaultCloseOperation(EXIT_ON_CLOSE);

setMinimumSize(new Dimension(800, 600));

 

String[] pages = {"首頁", "目錄", "翻牌學習", "測驗模式", "錯題複習", "統計資料", "新增單字"};

tabbedPane = new JTabbedPane();

cardLayout = new CardLayout();

cardPanel = new JPanel(cardLayout);

panelMap = new HashMap<>();

 

for (String page : pages) {

JPanel panel;

 

switch (page) {

case "翻牌學習":

panel = new FlashcardPanel();

break;

case "測驗模式":

panel = new QuizPanel();

break;

case "錯題複習":

panel = new WrongListPanel(wrongWords);

break;

case "統計資料":

panel = new StatsPanel();

break;

case "新增單字":

panel = new WordManagerPanel();

break;

case "首頁":

panel = new JPanel(new GridBagLayout());

panel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

JPanel titlePanel = new JPanel(new GridLayout(2, 1));

JLabel title1 = new JLabel("英文單字學習系統", SwingConstants.CENTER);

title1.setFont(new Font("標楷體", Font.BOLD, 30));

JLabel title2 = new JLabel("English Word Learning System", SwingConstants.CENTER);

title2.setFont(new Font("Serif", Font.PLAIN, 30));

titlePanel.add(title1);

titlePanel.add(title2);

panel.add(titlePanel, new GridBagConstraints());

panel.addMouseListener(new MouseAdapter() {

@Override

public void mouseClicked(MouseEvent e) {

tabbedPane.setSelectedIndex(1); // 目錄

}

});

break;

case "目錄":

panel = new JPanel(new BorderLayout());

JLabel title = new JLabel("英文單字學習系統", SwingConstants.CENTER);

title.setFont(new Font("標楷體", Font.BOLD, 25));

panel.add(title, BorderLayout.NORTH);

 

JPanel buttonPanel = new JPanel(new GridLayout(3, 2, 40, 20));

buttonPanel.setBorder(BorderFactory.createEmptyBorder(100, 200, 100, 200));

 

String[] targets = {"翻牌學習", "測驗模式", "錯題複習", "統計資料", "新增單字", "回到首頁"};

for (String target : targets) {

JButton button = new JButton(target);

button.setFont(new Font("標楷體", Font.PLAIN, 30));

button.setFocusPainted(false);

 

if (target.equals("回到首頁")) {

button.addActionListener(e -> tabbedPane.setSelectedIndex(0)); // 指定首頁 index

} else {

int targetIndex = java.util.Arrays.asList(pages).indexOf(target);

if (targetIndex != -1) {

button.addActionListener(e -> tabbedPane.setSelectedIndex(targetIndex));

}

}

buttonPanel.add(button);

}

 

panel.add(buttonPanel, BorderLayout.CENTER);

break;

default:

panel = new JPanel(new BorderLayout());

JLabel label = new JLabel(page, SwingConstants.CENTER);

label.setFont(new Font("標楷體", Font.BOLD, 30));

panel.add(label, BorderLayout.CENTER);

}

 

panelMap.put(page, panel);

tabbedPane.addTab(page, panel);

}

 

tabbedPane.addChangeListener(e -> {

int selectedIndex = tabbedPane.getSelectedIndex();

if (selectedIndex < 0) return;

 

String title = tabbedPane.getTitleAt(selectedIndex);

 

if (title.equals("錯題複習")) {

WrongListPanel wlp = (WrongListPanel) panelMap.get("錯題複習");

wlp.refreshList(wrongWords);

} else if (title.equals("統計資料")) {

StatsPanel sp = (StatsPanel) panelMap.get("統計資料");

sp.refresh();

} else if (title.equals("翻牌學習")) {

FlashcardPanel fp = new FlashcardPanel();

panelMap.put("翻牌學習", fp);

tabbedPane.setComponentAt(selectedIndex, fp);

} else if (title.equals("測驗模式")) {

QuizPanel qp = new QuizPanel();

panelMap.put("測驗模式", qp);

tabbedPane.setComponentAt(selectedIndex, qp);

}

});

 

setLayout(new BorderLayout());

add(tabbedPane, BorderLayout.CENTER);

tabbedPane.setSelectedIndex(0); // 預設首頁

}

 

public static void main(String[] args) {

SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));

}

}