package 作業2;

import java.util.ArrayList;
import java.util.List;

public class VocabularyData {
    private static final List<String[]> vocabulary = new ArrayList<>();

    static {
        vocabulary.add(new String[]{"apple", "蘋果"});
        vocabulary.add(new String[]{"banana", "香蕉"});
        vocabulary.add(new String[]{"cat", "貓"});
        vocabulary.add(new String[]{"dog", "狗"});
        vocabulary.add(new String[]{"elephant", "大象"});
    }

    public static List<String[]> getVocabulary() {
        return vocabulary;
    }

    public static void addWord(String eng, String chi) {
        vocabulary.add(new String[]{eng, chi});
    }

    public static void clearAndAddAll(List<String[]> newWords) {
        vocabulary.clear();
        vocabulary.addAll(newWords);
    }
}
