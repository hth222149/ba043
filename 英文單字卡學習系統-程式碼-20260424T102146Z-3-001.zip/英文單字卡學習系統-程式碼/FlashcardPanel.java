package 作業2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class FlashcardPanel extends JPanel {

    private JLabel cardLabel;
    private JButton nextButton;
    private boolean showingEnglish = true;
    private int currentIndex = 0;

    private List<String[]> vocabulary = VocabularyData.getVocabulary();

    public FlashcardPanel() {
        setLayout(new BorderLayout());

        JPanel cardContainer = new JPanel(new GridBagLayout());
        cardContainer.setBackground(new Color(240, 240, 240));

        cardLabel = new JLabel("", SwingConstants.CENTER);
        cardLabel.setFont(new Font("標楷體", Font.BOLD, 40));
        cardLabel.setOpaque(true);
        cardLabel.setBackground(Color.WHITE);
        cardLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        cardLabel.setPreferredSize(new Dimension(400, 200));
        cardLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        cardContainer.add(cardLabel);
        add(cardContainer, BorderLayout.CENTER);

        cardLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                toggleCard();
            }
        });

        nextButton = new JButton("下一題");
        nextButton.setFont(new Font("標楷體", Font.PLAIN, 20));
        nextButton.addActionListener(e -> showNextWord());

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(nextButton);
        add(bottomPanel, BorderLayout.SOUTH);

        updateCard();
    }

    private void toggleCard() {
        showingEnglish = !showingEnglish;
        updateCard();
    }

    private void showNextWord() {
        currentIndex = (currentIndex + 1) % vocabulary.size();
        showingEnglish = true;
        updateCard();
    }

    private void updateCard() {
        if (vocabulary.isEmpty()) return;
        cardLabel.setText(showingEnglish ? vocabulary.get(currentIndex)[0] : vocabulary.get(currentIndex)[1]);
    }
}
