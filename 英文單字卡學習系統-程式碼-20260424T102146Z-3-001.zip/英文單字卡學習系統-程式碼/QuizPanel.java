package 作業2;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import javax.swing.Timer;

public class QuizPanel extends JPanel {

    private JLabel questionLabel;
    private JLabel resultLabel;
    private JButton[] optionButtons;

    private int currentIndex = 0;
    private String correctAnswer;
    private List<String[]> vocabulary = VocabularyData.getVocabulary();

    public QuizPanel() {
        setLayout(new BorderLayout());

        // 顯示問題的標籤
        questionLabel = new JLabel("單字", SwingConstants.CENTER);
        questionLabel.setFont(new Font("標楷體", Font.BOLD, 30));
        add(questionLabel, BorderLayout.NORTH);

        // 顯示答對與否的提示文字
        resultLabel = new JLabel("", SwingConstants.CENTER);
        resultLabel.setFont(new Font("標楷體", Font.BOLD, 22));
        resultLabel.setForeground(Color.BLUE);

        // 中間區塊
        JPanel middlePanel = new JPanel();
        middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.Y_AXIS));
        middlePanel.setBorder(BorderFactory.createEmptyBorder(100, 180, 100, 180));

        middlePanel.add(resultLabel);
        middlePanel.add(Box.createVerticalStrut(20)); // 空隙

        // 建立選項按鈕
        JPanel optionPanel = new JPanel(new GridLayout(2, 2, 35, 35));
        optionButtons = new JButton[4];

        for (int i = 0; i < 4; i++) {
            JButton button = new JButton("選項");
            button.setFont(new Font("標楷體", Font.PLAIN, 30));
            button.setFocusPainted(false);
            int finalI = i;
            button.addActionListener(e -> checkAnswer(optionButtons[finalI].getText()));
            optionButtons[i] = button;
            optionPanel.add(button);
        }

        middlePanel.add(optionPanel);
        add(middlePanel, BorderLayout.CENTER);

        loadNextQuestion();
    }

    private void loadNextQuestion() {
        if (vocabulary.isEmpty()) {
            questionLabel.setText("❗ 無單字可測驗");
            for (JButton btn : optionButtons) {
                btn.setText("N/A");
                btn.setEnabled(false);
            }
            return;
        }

        currentIndex = (currentIndex + 1) % vocabulary.size();
        String[] current = vocabulary.get(currentIndex);
        String english = current[0];
        correctAnswer = current[1];

        questionLabel.setText("請選出「" + english + "」的中文意思");

        // 隨機生成選項
        List<String> options = new ArrayList<>();
        options.add(correctAnswer);
        Random rand = new Random();

        while (options.size() < 4) {
            String distractor = vocabulary.get(rand.nextInt(vocabulary.size()))[1];
            if (!options.contains(distractor)) {
                options.add(distractor);
            }
        }

        Collections.shuffle(options);
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText(options.get(i));
        }

        resultLabel.setText("");
    }

    private void checkAnswer(String selected) {
        MainFrame.totalAnswered++;

        if (selected.equals(correctAnswer)) {
            MainFrame.totalCorrect++;
            resultLabel.setText("✅ 答對了！");
        } else {
            resultLabel.setText("❌ 答錯了，正確答案是「" + correctAnswer + "」");

            boolean exists = false;
            for (String[] w : MainFrame.wrongWords) {
                if (w[0].equalsIgnoreCase(vocabulary.get(currentIndex)[0])) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                MainFrame.wrongWords.add(vocabulary.get(currentIndex));
            }
        }

        // 延遲兩秒顯示下一題
        Timer timer = new Timer(2000, e -> loadNextQuestion());
        timer.setRepeats(false);
        timer.start();
    }
}
