package 作業2;

import javax.swing.*;
import java.awt.*;

public class TabCardLayoutWindow extends JFrame {

    public TabCardLayoutWindow() {
        super("英文單字學習系統");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel cardPanel = new JPanel(new CardLayout());

        // 各頁面面板
        JPanel learnPanel = new FlashcardPanel();
        JPanel quizPanel = new QuizPanel();
        JPanel statsPanel = new StatsPanel();

        // 加入到 cardPanel 中
        cardPanel.add(learnPanel, "學習模式");
        cardPanel.add(quizPanel, "測驗模式");
        cardPanel.add(statsPanel, "統計資料");

        // 標籤選單
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("學習模式", null);
        tabbedPane.addTab("測驗模式", null);
        tabbedPane.addTab("統計資料", null);

        tabbedPane.addChangeListener(e -> {
            int idx = tabbedPane.getSelectedIndex();
            CardLayout cl = (CardLayout) cardPanel.getLayout();
            switch (idx) {
                case 0:
                    cl.show(cardPanel, "學習模式");
                    break;
                case 1:
                    cl.show(cardPanel, "測驗模式");
                    break;
                case 2:
                    cl.show(cardPanel, "統計資料");
                    break;
            }
        });

        tabbedPane.setSelectedIndex(0);
        add(tabbedPane, BorderLayout.NORTH);
        add(cardPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TabCardLayoutWindow().setVisible(true));
    }
}
