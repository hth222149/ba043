package 作業2;

import javax.swing.*;
import java.awt.*;

public class StatsPanel extends JPanel {

    private JLabel totalLabel;
    private JLabel correctLabel;
    private JLabel accuracyLabel;

    public StatsPanel() {
        setLayout(new GridLayout(3, 1));

        totalLabel = new JLabel();
        correctLabel = new JLabel();
        accuracyLabel = new JLabel();

        totalLabel.setFont(new Font("標楷體", Font.PLAIN, 24));
        correctLabel.setFont(new Font("標楷體", Font.PLAIN, 24));
        accuracyLabel.setFont(new Font("標楷體", Font.PLAIN, 24));

        add(totalLabel);
        add(correctLabel);
        add(accuracyLabel);

        refresh();
    }

    public void refresh() {
        int total = MainFrame.totalAnswered;
        int correct = MainFrame.totalCorrect;
        double accuracy = total == 0 ? 0 : (double) correct / total * 100;

        totalLabel.setText("總答題數： " + total);
        correctLabel.setText("正確題數： " + correct);
        accuracyLabel.setText(String.format("正確率： %.1f%%", accuracy));
    }
}
