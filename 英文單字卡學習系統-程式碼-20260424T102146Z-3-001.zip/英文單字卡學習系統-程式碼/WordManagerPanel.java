package 作業2;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class WordManagerPanel extends JPanel {

    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField engField;
    private JTextField chiField;

    public WordManagerPanel() {
        setLayout(new BorderLayout());

        // 表格標題欄
        String[] columnNames = {"英文", "中文"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // 頂部輸入區
        JPanel inputPanel = new JPanel(new FlowLayout());
        engField = new JTextField(10);
        chiField = new JTextField(10);
        JButton addButton = new JButton("新增");
        inputPanel.add(new JLabel("英文："));
        inputPanel.add(engField);
        inputPanel.add(new JLabel("中文："));
        inputPanel.add(chiField);
        inputPanel.add(addButton);

        // 底部按鈕區
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton deleteButton = new JButton("刪除選取列");
        JButton importButton = new JButton("匯入CSV檔");
        buttonPanel.add(deleteButton);
        buttonPanel.add(importButton);

        // 新增按鈕事件
        addButton.addActionListener(e -> {
            String eng = engField.getText().trim();
            String chi = chiField.getText().trim();
            if (!eng.isEmpty() && !chi.isEmpty()) {
                tableModel.addRow(new Object[]{eng, chi});
                VocabularyData.addWord(eng, chi);
                engField.setText("");
                chiField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "請輸入完整資料");
            }
        });

        // 刪除按鈕事件
        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                tableModel.removeRow(selectedRow);
            } else {
                JOptionPane.showMessageDialog(this, "請選擇一列來刪除");
            }
        });

        // 匯入 CSV 檔案事件
        importButton.addActionListener(e -> importFromCSV());

        // 排版
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void importFromCSV() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);

        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            int count = 0;
            List<String[]> importedWords = new ArrayList<>();

            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 2) {
                        String eng = parts[0].trim();
                        String chi = parts[1].trim();
                        if (!eng.isEmpty() && !chi.isEmpty()) {
                            tableModel.addRow(new Object[]{eng, chi});
                            importedWords.add(new String[]{eng, chi});
                            count++;
                        }
                    }
                }
                VocabularyData.clearAndAddAll(importedWords);
                JOptionPane.showMessageDialog(this, "成功匯入 " + count + " 筆單字！");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "讀取檔案失敗：" + ex.getMessage());
            }
        }
    }
}
