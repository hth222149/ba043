package 作業2;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class WrongListPanel extends JPanel {

    private DefaultListModel<String> listModel;
    private JList<String> wrongList;
    private JTextField answerField;
    private JLabel feedbackLabel;

    public void refreshList(List<String[]> wrongWords) {
        listModel.clear();
        for (String[] word : wrongWords) {
            listModel.addElement(word[1]);
        }
        answerField.setEnabled(false);
        feedbackLabel.setText("請選擇一個錯題並輸入對應的英文");
        feedbackLabel.setForeground(Color.DARK_GRAY);
    }

    public WrongListPanel(List<String[]> wrongWords) {
        setLayout(new BorderLayout());

        JLabel title = new JLabel("錯題複習", SwingConstants.CENTER);
        title.setFont(new Font("標楷體", Font.BOLD, 28));
        add(title, BorderLayout.NORTH);

        listModel = new DefaultListModel<>();
        wrongList = new JList<>(listModel);
        wrongList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(wrongList);
        add(scrollPane, BorderLayout.CENTER);

        for (String[] word : wrongWords) {
            listModel.addElement(word[1]);
        }

        JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
        answerField = new JTextField();
        answerField.setFont(new Font("標楷體", Font.PLAIN, 20));
        answerField.setEnabled(false);

        feedbackLabel = new JLabel("請選擇一個錯題並輸入對應的英文", SwingConstants.CENTER);
        feedbackLabel.setFont(new Font("標楷體", Font.BOLD, 16));
        feedbackLabel.setForeground(Color.DARK_GRAY);

        bottomPanel.add(answerField, BorderLayout.CENTER);
        bottomPanel.add(feedbackLabel, BorderLayout.SOUTH);
        add(bottomPanel, BorderLayout.SOUTH);

        wrongList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && wrongList.getSelectedIndex() != -1) {
                answerField.setEnabled(true);
                answerField.setText("");
                feedbackLabel.setText("請輸入對應英文，按 Enter 送出");
            }
        });

        answerField.addActionListener(e -> {
            int idx = wrongList.getSelectedIndex();
            if (idx == -1) return;

            String input = answerField.getText().trim().toLowerCase();
            String correctEnglish = wrongWords.get(idx)[0].toLowerCase();

            if (input.equals(correctEnglish)) {
                feedbackLabel.setText("✅ 答對了！");
                feedbackLabel.setForeground(new Color(0, 128, 0));
            } else {
                feedbackLabel.setText("❌ 答錯了，正確答案是：" + correctEnglish);
                feedbackLabel.setForeground(Color.RED);
            }

            answerField.selectAll();
        });
    }
}
