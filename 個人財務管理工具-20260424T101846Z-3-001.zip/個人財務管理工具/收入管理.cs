﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 個人財務管理工具
{
    public partial class 收入管理 : Form
    {
        public 收入管理()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            目錄 menuForm = new 目錄();
            FormManager.SwitchForm(menuForm);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            支出管理 incomeForm = new 支出管理();
            FormManager.SwitchForm(incomeForm);
        }
    }
}
