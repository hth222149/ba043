﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 個人財務管理工具
{
    public partial class 待機畫面 : Form
    {
        public 待機畫面()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized; // 最大化
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 創建目錄表單並切換到它
            目錄 menuForm = new 目錄();
            FormManager.SwitchForm(menuForm);

            // 隱藏待機畫面而不是關閉
            this.Hide();
        }

        private void 待機畫面_Load(object sender, EventArgs e)
        {

        }
    }
}
