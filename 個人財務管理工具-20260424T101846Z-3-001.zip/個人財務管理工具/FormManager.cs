﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 個人財務管理工具
{
    internal class FormManager
    {
        // 保存表單的堆疊
        private static Stack<Form> formStack = new Stack<Form>();

        /// <summary>
        /// 切換到新表單
        /// </summary>
        /// <param name="newForm">要顯示的新表單</param>
        public static void SwitchForm(Form newForm)
        {
            if (formStack.Count > 0)
            {
                // 隱藏當前表單但不關閉
                formStack.Peek().Hide();
            }

            // 將新表單壓入堆疊並顯示
            formStack.Push(newForm);
            newForm.StartPosition = FormStartPosition.CenterScreen;
            newForm.Show();
        }

        /// <summary>
        /// 返回上一個表單
        /// </summary>
        public static void ReturnToPreviousForm()
        {
            if (formStack.Count > 1)
            {
                // 關閉當前表單
                Form currentForm = formStack.Pop();
                currentForm.Close();

                // 顯示上一個表單
                formStack.Peek().Show();
            }
        }


    }
}

