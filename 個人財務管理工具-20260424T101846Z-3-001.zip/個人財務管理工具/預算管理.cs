﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 個人財務管理工具
{
    public partial class 預算管理 : Form
    {
        public 預算管理()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 創建目錄表單並切換到它
            目錄 menuForm = new 目錄();
            FormManager.SwitchForm(menuForm);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            報銷管理 incomeForm = new 報銷管理();
            FormManager.SwitchForm(incomeForm);
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
