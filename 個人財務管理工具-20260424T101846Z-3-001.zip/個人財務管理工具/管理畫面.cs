﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static 個人財務管理工具.管理畫面;

namespace 個人財務管理工具
{
    public partial class 管理畫面 : Form
    {

        public 管理畫面() // 構造函數：當表單初始化時，會執行這部分代碼
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized; // 設定視窗啟動時為最大化
        }

        private void 管理畫面_Load(object sender, EventArgs e) // 當表單載入時，會觸發此事件
        {
            // 設定 TabControl 控制項的預設選擇索引為 0，顯示第一個頁面
            tabControlMain.SelectedIndex = 0; // 預設顯示第一個頁面

            // 初始化 comboBox1 的選項，設定收入來源類別
            comboBox1.Items.AddRange(new string[] { "薪資", "獎金", "投資", "其他" });

            // 初始化 comboBox2 的選項，設定支出類別
            comboBox2.Items.AddRange(new string[] { "餐飲", "交通", "購物", "娛樂", "其他" });

            // 初始化 DataGridView 控制項，顯示收入或支出記錄
            InitializeDataGridView();

            // 初始化 listView1 和 listView2，分別顯示未報銷和已報銷的支出條目
            InitializeListView(listView1, "未報銷條目");  // 設定 listView1 為未報銷條目
            InitializeListView(listView2, "已報銷條目");  // 設定 listView2 為已報銷條目

            // 更新 DataGridView 的支出記錄顯示
            UpdateDataGridView();

            // 初始化 panel2 的收支比例圖表
            UpdatePanel2();  // 這是負責更新收支比例圖表的函式
        }

        private void InitializeDataGridView() // 初始化 DataGridView 顯示
        {
            // 清空現有的欄位設定
            dataGridView1.Columns.Clear();

            // 設定 DataGridView1 的欄位，顯示收入資料
            dataGridView1.Columns.Add("金額", "金額");               // 收入金額欄位
            dataGridView1.Columns.Add("類別", "類別");               // 來源類別欄位
            dataGridView1.Columns.Add("存入位置", "存入位置");       // 存入位置欄位
            dataGridView1.Columns.Add("存入日期", "存入日期");       // 存入日期欄位
            dataGridView1.Columns.Add("備註", "備註");               // 備註欄位

            // 自動調整欄寬以適應內容
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // 初始化 dataGridView2，顯示支出資料
            dataGridView2.Columns.Clear();  // 清空現有的欄位設定
            dataGridView2.Columns.Add("金額", "金額");                 // 支出金額欄位
            dataGridView2.Columns.Add("類別", "類別");                 // 支出類別欄位
            dataGridView2.Columns.Add("支付方式", "支付方式");         // 支付方式欄位
            dataGridView2.Columns.Add("支付日期", "支付日期");         // 支付日期欄位
            dataGridView2.Columns.Add("報銷狀態", "報銷狀態");         // 報銷狀態欄位
            dataGridView2.Columns.Add("備註", "備註");                 // 備註欄位

            // 自動調整欄寬以適應內容
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        // 動態切換 TabPage，根據名稱選擇對應的頁面
        public void SwitchToTabPage(string tabPageName)
        {
            // 遍歷所有 TabPages，根據名稱尋找對應的頁面
            foreach (TabPage tabPage in tabControlMain.TabPages)
            {
                // 如果找到了對應名稱的頁面，選擇該頁面
                if (tabPage.Name == tabPageName)
                {
                    tabControlMain.SelectedTab = tabPage; // 切換到指定頁面
                    return;
                }
            }

            // 如果找不到對應的 TabPage，顯示錯誤訊息
            MessageBox.Show($"TabPage '{tabPageName}' 不存在！");
        }

        // 建立清單來儲存收入和支出資料
        private List<收入資料> 收入清單 = new List<收入資料>();  // 用來儲存收入資料的清單
        private List<支出資料> 支出清單 = new List<支出資料>();  // 用來儲存支出資料的清單

        public class 收入資料 // 定義儲存收入資料的結構
        {
            public decimal 金額 { get; set; }         // 收入金額
            public string 類別 { get; set; }          // 來源類別
            public string 存入位置 { get; set; }      // 存入位置
            public DateTime 存入日期 { get; set; }    // 存入日期
            public string 備註 { get; set; }          // 備註

        }

        private void 更新收入表格() // 更新收入表格顯示資料
        {
            // 清空收入表格現有的資料
            dataGridView1.Rows.Clear();

            // 更新收入資料到 dataGridView1
            foreach (var 收入 in 收入清單)
            {
                // 新增一行到收入表格
                dataGridView1.Rows.Add(new object[]
                {
                    收入.金額.ToString("C"),                // 金額：顯示為貨幣格式
                    收入.類別,                             // 類別：顯示收入類別
                    收入.存入位置,                         // 存入位置：顯示存入的帳戶或方式
                    收入.存入日期.ToShortDateString(),     // 存入日期：顯示簡短格式日期
                    收入.備註                              // 備註：顯示備註內容
                });
            }
        }

        private void button1_Click(object sender, EventArgs e) // 儲存按鈕
        {
            try
            {
                // 獲取並驗證輸入的收入金額，若無效則顯示錯誤訊息
                if (!decimal.TryParse(textBox1.Text, out decimal 金額) || 金額 <= 0)
                {
                    // 若金額無效，顯示錯誤訊息
                    MessageBox.Show("請輸入有效的金額！", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 收集其他輸入資料
                string 類別 = comboBox1.SelectedItem?.ToString() ?? "未指定"; // 來源類別
                string 存入位置 = textBox2.Text; // 存入位置
                DateTime 存入日期 = dateTimePicker1.Value; // 存入日期
                string 備註 = textBox3.Text; // 備註

                // 新增收入資料至清單中
                收入清單.Add(new 收入資料
                {
                    金額 = 金額,
                    類別 = 類別,
                    存入位置 = 存入位置,
                    存入日期 = 存入日期,
                    備註 = 備註,
                });

                // 更新收入表格，並清空輸入欄位
                更新收入表格();
                // 顯示儲存成功的訊息
                MessageBox.Show("收入資料已成功儲存！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // 清空輸入欄位，準備下一筆資料
                textBox1.Clear();
                comboBox1.SelectedIndex = -1;
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception ex)
            {
                // 捕捉異常，顯示錯誤訊息
                MessageBox.Show($"發生錯誤：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 返回目錄按鈕的事件處理方法
        private void button2_Click(object sender, EventArgs e)
        {
            // 創建一個新的目錄表單實例
            目錄 menuForm = new 目錄();

            // 使用 FormManager 切換到目錄表單
            FormManager.SwitchForm(menuForm);
        }

        // 進入下一頁按鈕的事件處理方法
        private void button3_Click(object sender, EventArgs e)
        {
            // 獲取當前選中的頁籤索引
            int currentIndex = tabControlMain.SelectedIndex;

            // 檢查是否有下一頁
            if (currentIndex < tabControlMain.TabCount - 1)
            {
                // 切換到下一頁
                tabControlMain.SelectedIndex = currentIndex + 1;
            }
            else
            {
                // 若已是最後一頁，顯示提示訊息
                MessageBox.Show("已是最後一頁！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // 返回上一頁按鈕的點擊事件
        private void button14_Click(object sender, EventArgs e)
        {
            // 獲取當前選中的 Tab 頁索引
            int currentIndex = tabControlMain.SelectedIndex;

            // 判斷是否已經是第一頁，若不是則切換到上一頁
            if (currentIndex > 0)
            {
                tabControlMain.SelectedIndex = currentIndex - 1; // 切換到上一頁
            }
            else
            {
                // 若已是第一頁，顯示提示訊息
                MessageBox.Show("已是第一頁！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public class 支出資料 // 定義支出資料結構
        {
            public decimal 金額 { get; set; }          // 支出金額
            public string 類別 { get; set; }           // 支出類別
            public bool 已報銷 { get; set; }          // 是否已報銷
            public string 支付方式 { get; set; }      // 支付方式（如現金、信用卡等）
            public DateTime 支出日期 { get; set; }    // 支出日期
            public string 備註 { get; set; }          // 備註
        }

        // 勾選已報銷選項時的處理邏輯
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                checkBox2.Checked = false; // 當已報銷勾選時，取消未報銷的勾選
            }
        }

        // 勾選未報銷選項時的處理邏輯
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                checkBox1.Checked = false; // 當未報銷勾選時，取消已報銷的勾選
            }
        }

        // 更新支出表格顯示資料
        private void 更新支出表格() // 更新支出資料的 DataGridView
        {
            // 清空支出表格現有的資料
            dataGridView2.Rows.Clear();

            // 更新支出資料到 dataGridView2
            foreach (var 支出 in 支出清單)
            {
                // 新增一行到支出表格
                dataGridView2.Rows.Add(new object[]
                {
                    支出.金額.ToString("C"),               // 金額：顯示為貨幣格式
                    支出.類別,                             // 類別：顯示支出類別
                    支出.支付方式,                         // 支付方式：顯示支付方式
                    支出.支出日期.ToShortDateString(),     // 支出日期：顯示簡短格式日期
                    支出.已報銷 ? "已報銷" : "未報銷",       // 報銷狀態：顯示是否已報銷
                    支出.備註                              // 備註：顯示備註內容
                });
            }
        }

        private void UpdateDataGridView() // 更新 DataGridView 控制項的支出資料顯示
        {
            // 清空 DataGridView 中的現有資料行
            dataGridView2.Rows.Clear();

            // 遍歷支出清單，將支出資料添加到 DataGridView
            foreach (var 支出 in 支出清單)
            {
                // 建立一筆資料行，對應每筆支出的詳細內容
                var row = new string[]
                {
                    支出.金額.ToString("C"),          // 金額：格式化為貨幣格式（如 NT$1,000.00）
                    支出.類別,                        // 類別：顯示支出的來源類別
                    支出.支付方式,                    // 支付方式：顯示支付的方式（如現金、信用卡等）
                    支出.支出日期.ToShortDateString(), // 支出日期：以簡短日期格式顯示
                    支出.備註,                        // 備註：顯示支出的備註資訊
                    支出.已報銷 ? "已報銷" : "未報銷" // 報銷狀態：顯示已報銷或未報銷
                };

                // 根據篩選條件決定是否將該筆資料顯示在 DataGridView
                if (checkBox1.Checked && 支出.已報銷) // 如果勾選了「已報銷」，只顯示已報銷的支出項目
                {
                    dataGridView2.Rows.Add(row); // 添加到 DataGridView
                }
                else if (checkBox2.Checked && !支出.已報銷) // 如果勾選了「未報銷」，只顯示未報銷的支出項目
                {
                    dataGridView2.Rows.Add(row); // 添加到 DataGridView
                }
                else if (!checkBox1.Checked && !checkBox2.Checked) // 如果未勾選任何篩選條件，顯示所有支出項目
                {
                    dataGridView2.Rows.Add(row); // 添加到 DataGridView
                }
            }
        }

        private void InitializeListView(ListView listView, string headerText) // 初始化 ListView 控制項，設置其顯示格式和列標題
        {
            // 設定 ListView 的顯示模式為詳細資料模式（顯示表格）
            listView.View = View.Details;

            // 啟用選擇整行（選擇一行時會高亮顯示整行）
            listView.FullRowSelect = true;

            // 清空現有的欄位設定
            listView.Columns.Clear();

            // 添加自定義的欄位，設置顯示標題和寬度
            listView.Columns.Add("金額", 80);      // 第一個欄位，顯示金額
            listView.Columns.Add("類別", 60);      // 第二個欄位，顯示類別
            listView.Columns.Add("支付方式", 70);  // 第三個欄位，顯示支付方式
            listView.Columns.Add("日期", 80);      // 第四個欄位，顯示日期
            listView.Columns.Add("備註", 100);      // 第五個欄位，顯示備註

        }

        // 更新 ListView 顯示的支出條目
        private void 更新ListView內容()
        {
            // 清空現有的列表項目
            listView1.Items.Clear();
            listView2.Items.Clear();

            // 更新未報銷條目到 listView1
            var 未報銷條目 = 支出清單.Where(支出 => !支出.已報銷); // 過濾出未報銷的支出
            foreach (var 支出 in 未報銷條目)
            {
                // 創建 ListView 項目並添加到 listView1
                var item = new ListViewItem(new string[]
                {
                    支出.金額.ToString("C"),        // 金額：顯示為貨幣格式
                    支出.類別,                     // 類別：顯示支出類別
                    支出.支付方式,                 // 支付方式：顯示支付方式
                    支出.支出日期.ToShortDateString(), // 支出日期：顯示簡短格式日期
                    支出.備註                      // 備註：顯示備註內容
                });
                listView1.Items.Add(item); // 添加到 listView1（未報銷）
            }

            // 更新已報銷條目到 listView2
            var 已報銷條目 = 支出清單.Where(支出 => 支出.已報銷); // 過濾出已報銷的支出
            foreach (var 支出 in 已報銷條目)
            {
                // 創建 ListView 項目並添加到 listView2
                var item = new ListViewItem(new string[]
                {
                    支出.金額.ToString("C"),        // 金額：顯示為貨幣格式
                    支出.類別,                     // 類別：顯示支出類別
                    支出.支付方式,                 // 支付方式：顯示支付方式
                    支出.支出日期.ToShortDateString(), // 支出日期：顯示簡短格式日期
                    支出.備註                      // 備註：顯示備註內容
                });
                listView2.Items.Add(item); // 添加到 listView2（已報銷）
            }
        }

        // 更新 panel2 以顯示收支比例圖
        private void UpdatePanel2()
        {
            decimal 總收入 = 10000; // 模擬的總收入數據
            decimal 總支出 = 支出清單.Sum(s => s.金額); // 計算總支出（從支出清單累加）

            // 計算支出比例，防止總收入為零的情況
            float 支出比例 = 總收入 > 0 ? (float)(總支出 / 總收入) : 0;

            // 清空 panel2 中的現有控制項
            panel2.Controls.Clear();

            // 創建一個進度條顯示支出比例
            ProgressBar progressBar = new ProgressBar
            {
                Dock = DockStyle.Fill,   // 讓進度條佔滿整個 panel
                Minimum = 0,             // 設定最小值
                Maximum = 100,           // 設定最大值
                Value = (int)(支出比例 * 100), // 設定目前值，轉換為百分比顯示
                ForeColor = 支出比例 > 1 ? Color.Red : Color.Green // 根據比例設定顏色，若比例大於1則顯示紅色
            };

            // 將進度條加入 panel2 控制項中
            panel2.Controls.Add(progressBar);

            // 創建顯示收支比例、支出總額和收入總額的標籤
            Label label = new Label
            {
                Dock = DockStyle.Bottom, // 顯示於 panel 底部
                Text = $"支出比例: {支出比例:P2} (支出: {總支出:C}, 收入: {總收入:C})", // 顯示格式化的支出比例、支出和收入金額
                TextAlign = ContentAlignment.MiddleCenter, // 文字居中顯示
                Font = new Font("Arial", 12, FontStyle.Bold) // 設定字型與大小
            };

            // 將標籤加入 panel2 控制項中
            panel2.Controls.Add(label);
        }

        // 進入下一頁按鈕的事件處理方法
        private void button4_Click(object sender, EventArgs e)
        {
            // 獲取當前選中的頁籤索引
            int currentIndex = tabControlMain.SelectedIndex;

            // 檢查是否有下一頁
            if (currentIndex < tabControlMain.TabCount - 1)
            {
                // 切換到下一頁
                tabControlMain.SelectedIndex = currentIndex + 1;
            }
            else
            {
                // 若已是最後一頁，顯示提示訊息
                MessageBox.Show("已是最後一頁！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // 返回目錄按鈕的事件處理方法
        private void button5_Click(object sender, EventArgs e)
        {
            // 創建一個新的目錄表單實例
            目錄 menuForm = new 目錄();

            // 使用 FormManager 切換到目錄表單
            FormManager.SwitchForm(menuForm);
        }

        // 儲存支出的按鈕事件處理方法
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                // 驗證輸入的支出金額，若無效則顯示錯誤訊息
                if (!decimal.TryParse(textBox4.Text, out decimal 金額) || 金額 <= 0)
                {
                    MessageBox.Show("請輸入有效的金額！", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 收集輸入的其他支出資料
                string 類別 = comboBox2.SelectedItem?.ToString() ?? "未指定"; // 流向類別（例如餐飲、交通等）
                bool 已報銷 = checkBox1.Checked; // 是否已報銷
                string 支付方式 = textBox5.Text; // 支付方式（例如現金、信用卡等）
                DateTime 支出日期 = dateTimePicker2.Value; // 支出日期
                string 備註 = textBox6.Text; // 備註信息

                // 創建新的支出資料物件
                支出資料 新支出 = new 支出資料
                {
                    金額 = 金額,
                    類別 = 類別,
                    已報銷 = 已報銷,
                    支付方式 = 支付方式,
                    支出日期 = 支出日期,
                    備註 = 備註
                };

                // 將新支出資料加入支出清單
                支出清單.Add(新支出);

                // 更新支出資料在 DataGridView 中顯示
                更新支出表格();

                // 更新 ListView 顯示，即時反映新增的支出資料
                更新ListView內容();

                // 顯示成功訊息
                MessageBox.Show("支出資料已成功儲存！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // 清空所有輸入欄位，準備下一次輸入
                textBox4.Clear();
                comboBox2.SelectedIndex = -1;
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                textBox5.Clear();
                textBox6.Clear();
            }
            catch (Exception ex)
            {
                // 顯示錯誤訊息
                MessageBox.Show($"發生錯誤：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 返回上一頁按鈕的點擊事件 (button15)
        private void button15_Click(object sender, EventArgs e)
        {
            // 獲取當前選中的 Tab 頁索引
            int currentIndex = tabControlMain.SelectedIndex;

            // 檢查是否已經是第一頁
            if (currentIndex > 0)
            {
                tabControlMain.SelectedIndex = currentIndex - 1; // 切換到上一頁
            }
            else
            {
                // 若已是第一頁，顯示提示訊息
                MessageBox.Show("已是第一頁！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // 更新預算圖表顯示數字的方法
        private void 更新預算圖表顯示數字(decimal 預算金額, decimal 已使用金額, decimal 剩餘預算)
        {
            // 清空現有的圖表顯示
            panel1.Controls.Clear();

            // 創建一個新的圖表實例
            var chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            chart.Dock = DockStyle.Fill;

            // 設置圖表區域
            var chartArea = new System.Windows.Forms.DataVisualization.Charting.ChartArea("預算使用情況");
            chart.ChartAreas.Add(chartArea);

            // 創建資料系列，並設為圓餅圖
            var series = new System.Windows.Forms.DataVisualization.Charting.Series("預算");
            series.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;

            // 將已使用金額和剩餘預算添加至圖表
            series.Points.AddXY("已使用", 已使用金額);
            series.Points.AddXY("剩餘", Math.Max(剩餘預算, 0)); // 確保剩餘預算不為負值

            // 將資料系列添加至圖表
            chart.Series.Add(series);

            // 自定義顏色，已使用部分為紅色，剩餘部分為綠色
            series.Points[0].Color = ColorTranslator.FromHtml("#FFC1C1");    // 已使用部分
            series.Points[1].Color = ColorTranslator.FromHtml("#B4EEB4");   // 剩餘部分

            // 顯示資料標籤，顯示貨幣格式
            series.IsValueShownAsLabel = true;
            series.LabelFormat = "C"; // 顯示貨幣格式（例如 $100.00）

            // 添加圖例
            var legend = new System.Windows.Forms.DataVisualization.Charting.Legend("圖例");
            chart.Legends.Add(legend);

            // 將圖表添加至 panel1 中顯示
            panel1.Controls.Add(chart);
        }

        // 進入下一頁按鈕的點擊事件
        private void button7_Click(object sender, EventArgs e)
        {
            // 獲取當前選中的 Tab 頁索引
            int currentIndex = tabControlMain.SelectedIndex;

            // 判斷是否還有下一頁，若有則切換到下一頁
            if (currentIndex < tabControlMain.TabCount - 1)
            {
                tabControlMain.SelectedIndex = currentIndex + 1;
            }
            else
            {
                // 若已是最後一頁，顯示提示訊息
                MessageBox.Show("已是最後一頁！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // 返回目錄按鈕的點擊事件
        private void button8_Click(object sender, EventArgs e)
        {
            // 創建目錄頁面並切換
            目錄 menuForm = new 目錄();
            FormManager.SwitchForm(menuForm);
        }

        // 儲存預算金額的變數
        private decimal 儲存的預算金額 = 0;

        // 儲存預算按鈕的點擊事件
        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                // 獲取輸入的預算金額，並進行驗證
                if (!decimal.TryParse(textBox7.Text, out 儲存的預算金額) || 儲存的預算金額 <= 0)
                {
                    MessageBox.Show("請輸入有效的預算金額！", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 顯示儲存成功的提示訊息
                MessageBox.Show($"預算金額 {儲存的預算金額:C} 已成功儲存！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // 捕捉異常並顯示錯誤訊息
                MessageBox.Show($"發生錯誤：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // 清空預算金額輸入框
            textBox7.Clear();
        }

        // 返回上一頁按鈕的點擊事件 (button16)
        private void button16_Click(object sender, EventArgs e)
        {
            // 與 button15 的邏輯相同
            int currentIndex = tabControlMain.SelectedIndex;

            if (currentIndex > 0)
            {
                tabControlMain.SelectedIndex = currentIndex - 1;
            }
            else
            {
                MessageBox.Show("已是第一頁！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // 更新預算圖表並處理範圍內的支出計算 (button19)
        private void button19_Click(object sender, EventArgs e)
        {
            try
            {
                // 檢查是否有設定有效的預算金額
                if (儲存的預算金額 <= 0)
                {
                    MessageBox.Show("請先設定並儲存預算金額！", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 獲取日期範圍
                DateTime 開始日期 = dateTimePicker3.Value.Date;
                DateTime 結束日期 = dateTimePicker4.Value.Date;

                // 驗證日期範圍
                if (開始日期 > 結束日期)
                {
                    MessageBox.Show("開始日期不能晚於結束日期！", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 計算範圍內未報銷的支出總額
                decimal 未報銷支出總額 = 支出清單
                    .Where(支出 => 支出.支出日期.Date >= 開始日期 &&
                                  支出.支出日期.Date <= 結束日期 &&
                                  !支出.已報銷)
                    .Sum(支出 => 支出.金額);

                // 計算剩餘預算
                decimal 剩餘預算 = 儲存的預算金額 - 未報銷支出總額;

                // 更新圖表顯示
                更新預算圖表顯示數字(儲存的預算金額, 未報銷支出總額, 剩餘預算);

                // 提示是否超支
                if (剩餘預算 < 0)
                {
                    MessageBox.Show($"超支警告！您已超支 {Math.Abs(剩餘預算):C}。", "超支警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show("圖表已成功更新！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // 捕捉異常並顯示錯誤訊息
                MessageBox.Show($"發生錯誤：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 進入下一頁按鈕的點擊事件
        private void button10_Click(object sender, EventArgs e)
        {
            // 獲取當前選中的 Tab 頁索引
            int currentIndex = tabControlMain.SelectedIndex;

            // 判斷是否還有下一頁，若有則切換到下一頁
            if (currentIndex < tabControlMain.TabCount - 1)
            {
                tabControlMain.SelectedIndex = currentIndex + 1; // 切換到下一個頁面
            }
            else
            {
                // 若已是最後一頁，顯示提示訊息
                MessageBox.Show("已是最後一頁！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // 返回目錄按鈕的點擊事件
        private void button11_Click(object sender, EventArgs e)
        {
            // 創建目錄頁面並切換
            var menuForm = new 目錄();
            FormManager.SwitchForm(menuForm);
        }

        // 返回上一頁按鈕的點擊事件 (button17)
        private void button17_Click(object sender, EventArgs e)
        {
            // 與 button15 的邏輯相同
            int currentIndex = tabControlMain.SelectedIndex;

            if (currentIndex > 0)
            {
                tabControlMain.SelectedIndex = currentIndex - 1;
            }
            else
            {
                MessageBox.Show("已是第一頁！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // 返回待機畫面按鈕的點擊事件
        private void button12_Click(object sender, EventArgs e)
        {
            // 創建待機畫面並切換
            待機畫面 incomeForm = new 待機畫面();
            FormManager.SwitchForm(incomeForm);
        }

        // 返回目錄按鈕的點擊事件
        private void button13_Click(object sender, EventArgs e)
        {
            // 創建目錄頁面並切換
            var menuForm = new 目錄();
            FormManager.SwitchForm(menuForm);
        }

        // 返回上一頁按鈕的點擊事件 (button18)
        private void button18_Click(object sender, EventArgs e)
        {
            // 與 button15 的邏輯相同
            int currentIndex = tabControlMain.SelectedIndex;

            if (currentIndex > 0)
            {
                tabControlMain.SelectedIndex = currentIndex - 1;
            }
            else
            {
                MessageBox.Show("已是第一頁！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // 更新收支比例圖表 (button20)
        private void button20_Click(object sender, EventArgs e)
        {
            try
            {
                // 計算總收入
                decimal 總收入 = 收入清單.Sum(收入 => 收入.金額);

                // 計算未報銷的總支出
                decimal 總支出 = 支出清單.Where(支出 => !支出.已報銷).Sum(支出 => 支出.金額);

                // 計算收入與支出的比例
                decimal 收支比例 = 總收入 + 總支出 > 0 ? 總收入 / (總收入 + 總支出) : 0;

                // 清空 panel2 以移除舊的圖表
                panel2.Controls.Clear();

                // 創建圖表物件
                var chart = new System.Windows.Forms.DataVisualization.Charting.Chart
                {
                    Dock = DockStyle.Fill
                };

                // 添加圖表區域
                var chartArea = new System.Windows.Forms.DataVisualization.Charting.ChartArea("收支比例");
                chart.ChartAreas.Add(chartArea);

                // 添加資料系列
                var series = new System.Windows.Forms.DataVisualization.Charting.Series("收支比例")
                {
                    ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie
                };

                // 設置資料點
                series.Points.AddXY("收入", 總收入);
                series.Points.AddXY("支出", 總支出);

                chart.Series.Add(series);

                // 自定義顏色
                series.Points[0].Color = ColorTranslator.FromHtml("#C6E2FF");     // 收入部分
                series.Points[1].Color = ColorTranslator.FromHtml("#FFFACD");     // 支出部分
                
                // 顯示數字標籤
                series.IsValueShownAsLabel = true;
                series.LabelFormat = "C"; // 顯示貨幣格式

                // 添加圖例
                var legend = new System.Windows.Forms.DataVisualization.Charting.Legend("圖例");
                chart.Legends.Add(legend);

                // 將圖表添加到 panel2
                panel2.Controls.Add(chart);
            }
            catch (Exception ex)
            {
                // 捕捉異常並顯示錯誤訊息
                MessageBox.Show($"發生錯誤：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }


}
