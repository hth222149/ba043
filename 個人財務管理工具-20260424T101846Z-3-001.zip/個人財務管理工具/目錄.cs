﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 個人財務管理工具
{
    public partial class 目錄 : Form
    {
        public 目錄()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized; // 最大化
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            管理畫面 incomeForm = new 管理畫面();
            FormManager.SwitchForm(incomeForm);

            // 動態切換到 TabPage2
            incomeForm.SwitchToTabPage("tabPage1");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            管理畫面 incomeForm = new 管理畫面();
            FormManager.SwitchForm(incomeForm);

            // 動態切換到 TabPage2
            incomeForm.SwitchToTabPage("tabPage2");
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            管理畫面 incomeForm = new 管理畫面();
            FormManager.SwitchForm(incomeForm);

            // 動態切換到 TabPage2
            incomeForm.SwitchToTabPage("tabPage3");
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            管理畫面 incomeForm = new 管理畫面();
            FormManager.SwitchForm(incomeForm);

            // 動態切換到 TabPage2
            incomeForm.SwitchToTabPage("tabPage4");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            管理畫面 incomeForm = new 管理畫面();
            FormManager.SwitchForm(incomeForm);

            // 動態切換到 TabPage2
            incomeForm.SwitchToTabPage("tabPage5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            待機畫面 incomeForm = new 待機畫面();
            FormManager.SwitchForm(incomeForm);
        }

    }
}
