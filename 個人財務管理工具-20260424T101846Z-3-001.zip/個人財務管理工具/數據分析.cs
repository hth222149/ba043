﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 個人財務管理工具
{
    public partial class 數據分析 : Form
    {
        public 數據分析()
        {
            InitializeComponent();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // 創建目錄表單並切換到它
            目錄 menuForm = new 目錄();
            FormManager.SwitchForm(menuForm);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            待機畫面 incomeForm = new 待機畫面();
            FormManager.SwitchForm(incomeForm);
        }
    }
}
